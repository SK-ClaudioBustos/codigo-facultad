<?php 
    try{
		$mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
		$partes = explode('-', $_POST['fundacion']); 
    	$fecha = $partes[2]."-".$partes[1]."-".$partes[0];
		$sql = "update club
				set clu_nombre_largo='".$_POST['nombre_largo']."', 
					clu_nombre_medio='".$_POST['nombre_medio']."', 
					clu_nombre_corto='".$_POST['nombre_corto']."', 
					clu_fundacion='".$fecha."', 
					clu_ciudad='".$_POST['ciudad']."', 
					clu_pais='".$_POST['pais']."'
				where clu_id='".$_GET['selection']."'";
		$mysqli->query($sql);
		$mysqli->close();
		header("location:inicio.php");
	}
	catch(Exception $error){
        $msg_error = mysqli_connect_error();
        $msg_error_code = mysqli_errno($mysqli);
        $mysqli->close();
        header("location:inicio.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code"); 
    }  
?>