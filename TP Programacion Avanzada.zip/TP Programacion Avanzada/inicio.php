<?php
	require_once("./includes/inc_verification.php");
?>

<!DOCTYPE html>
<html>

	<head>
		<title>Página principal</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
		<link rel="stylesheet" type="text/css" href="./css/tabla.css">
	</head>
	
	<body class="h-100 bg-black text-white text-center">
		<?php
			require_once("./includes/inc_header.php");
		?>	
		<span class="text-success">
			¡Bienvenido! Usted ha ingresado correctamente.
		</span>
		<?php
			try{
				$mysqli = new mysqli('localhost', '2022_grupo1', 'Grupo1_2090', '2022_grupo1');
				$sql = "SELECT * FROM club";
		        if( $resultado = $mysqli->query($sql) )
		        {
		            if ( $resultado->num_rows == 0 )
		            {
		                $resultado= false;
		            }
		        }
		        $mysqli->close();
				if ( $resultado!=false){
		                $filas='';
		                $selection='nada';
		                while ( $club = $resultado->fetch_assoc()){
		                		$selection = $club["clu_id"];
		                    	$filas.='<tr>';
		                        $filas.='<td scope="row">'.$club["clu_id"].'</td>';
		                        $filas.='<td>'.$club["clu_nombre_largo"].'</td>';
		                        $filas.='<td>'.$club["clu_nombre_medio"].'</td>';
		                        $filas.='<td>'.$club["clu_nombre_corto"].'</td>';
		                        $filas.='<td>'.$club["clu_fundacion"].'</td>';
		                        $filas.='<td>'.$club["clu_ciudad"].'</td>';
								$filas.='<td>'.$club["clu_pais"].'</td>';
		                        $filas.=
		                        '<td>
		                        	<form action="edicion.php?selection='.$selection.'" method="post">
		                        		<button type="submit" class="btn btn-outline-warning btn-sm">Editar</button>
		                        	</form>
								</td>';

		                        $filas.=
		                        '<td>
		                        	<form action="borrarClub.php?selection='.$selection.'" enctype="multipart/form-data" method="post">
		                        		<button type="submit" class="btn btn-outline-danger btn-sm">Borrar</button>
		                        	</form>
		                        </td>';
		                    	$filas.='</tr>';
		                }
		        }else{
		            $filas='<tr><td colspan="7">No existen datos que mostrar</td></tr>';
		        }
		        $tabla = '<table id="listadoClubes" class="table text-white">
		                    <thead>
		                        <tr>
		                            <th scope="col">Id Club</th>                     
		                            <th scope="col">Nombre largo</th>
		                            <th scope="col">Nombre corto</th>
		                            <th scope="col">Abreviación</th>
		                            <th scope="col">Fundación</th>
		                            <th scope="col">Ciudad</th>
									<th scope="col">País</th>
		                            <th scope="col">Editar</th>
		                            <th scope="col">Eliminar</th>
		                        </tr>
		                    </thead>
		                    <tbody>'.$filas.'</tbody>
		                    </table>
		                    ';
		        ?>
		        <div class="d-flex justify-content-center">
		        	<button class="btn btn-success mt-1" data-bs-target="#modal-agregarClub" data-bs-toggle="modal" >
		        		Agregar nuevo club
		        	</button>
		        </div>
				<!-- Comienzo pop up agregar -->
							        <div id="modal-agregarClub" class="modal fade" tabindex="-1" role="dialog">
										<div class="modal-dialog modal-dialog-centered">
											<div class="modal-content bg-dark text-white">
												<div class="modal-header">
													<h5 class="modal-title">Agregar</h5>
												</div>
												<div class="modal-body">
													<!-- Comienzo del formulario -->
													<form action="agregarClub.php" method="post" class="row g-3">
														<div class="row-auto">
															<input pattern="[a-zA-Z\s]+" title="Nombre largo del club" type="text" class="form-control text-black" name="nombre_largo" placeholder="Nombre Largo" required></br>
															<input pattern="[a-zA-Z\s]+" title="Nombre corto" type="text" class="form-control text-black" name="nombre_medio" placeholder="Nombre Corto" required>
															<input pattern="[a-zA-Z]+" minlenght="3" maxlength="3" title="Abreviación(solo 3 caracteres)" type="text" class="form-control mt-4 text-black" name="nombre_corto" placeholder="Abreviación" required>
															<input pattern="([0-9]{2}-[0-9]{2}-[0-9]{4})+" title="Fecha de fundación(dd-mm-aaaa)" type="text" class="form-control mt-4 text-black" name="fundacion" placeholder="Fecha de Fundación" required>
															<input pattern="[a-zA-Z\s]+" title="Ciudad" type="text" class="form-control mt-4 text-black" name="ciudad" placeholder="Ciudad" required>
															<input pattern="[a-zA-Z\s]+" title="País" type="text" class="form-control mt-4 text-black" name="pais" placeholder="Pais" required>
														</div>
														<div class="modal-footer">
															<button type="submit" class="btn btn-success">Confirmar</button>
															<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
														</div>
													</form>
													<!-- Fin del formulario-->
												</div>
											</div>
										</div>
									</div>
				<!-- Fin pop up agregar -->
		        <?php
				echo $tabla;
			}
			catch(Exception $error){
				$msg_error = mysqli_connect_error();
		        $msg_error_code = mysqli_errno($mysqli);
		        $mysqli->close();
		        ?>
		        <script>
		        	console.log(<?php $msg_error ?>);
		        	console.log(<?php $msg_error_code ?>);
		        </script>
		        <div class="justify-content-center text-danger">
		        	"No se ha podido conectar a la Base de Datos"
		        </div>
		        <?php
			}

        ?>
		<script  src="https://code.jquery.com/jquery-3.6.1.js"  integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
		<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
		<script>
			$(document).ready( function () {
				$('#listadoClubes').DataTable( {
					"language":{
						"lengthMenu": "Mostrar _MENU_ registros",
						"zeroRecords": "No se han encontrado registros",
						"info": "Mostrando página _PAGE_ de _PAGES_",
						"infoEmpty": "No se han encontrado registros",
						"infoFiltered": "(filtrando de un total de _MAX_ registros)",
						"search": "Buscar:",
						"paginate": {
							"first":      "Primero",
							"last":       "Último",
							"next":       "Siguiente",
							"previous":   "Anterior"
						},
					}
				});
			});
		</script>
	</body>
	<div class="fixed-bottom">
		<?php 
			require_once("./includes/inc_footer.php");
		?>
	</div>
</html>	

	