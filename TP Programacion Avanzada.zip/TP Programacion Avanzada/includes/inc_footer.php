<footer class="bg-dark text-white p-3 w-100 d-flex flex-wrap justify-content-between fixed-bottom">
    <div class="col-6 d-flex"><small>Página Web desarrollada por: Silvia Simoine - Claudio Bustos - Nahuel Ibarra </small></div>
	<div class="col-6 d-flex justify-content-end">
		<a class="px-1" target="_blank" href="https://es-la.facebook.com/"><img src="./img/logo-facebook.png" alt="Facebook"></a>
		<a class="px-1" target="_blank" href="https://mobile.twitter.com/CopaNediel"><img src="./img/logo-twitter.png" alt="Twitter"></a>
		<a class="px-1" target="_blank" href="https://www.instagram.com/"><img src="./img/logo-instagram.png" alt="Instagram"></a>
		<a class="px-1" target="_blank" href="https://www.whatsapp.com/?lang=es"><img src="./img/logo-whatsapp.png" alt="Whatsapp"></a>
		<a class="px-1" target="_blank" href="https://www.twitch.tv/copanediel"><img src="./img/logo-twitch.png" alt="Twitch"></a>
	</div>
</footer>