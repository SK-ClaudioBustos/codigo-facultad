<!-- comienzo de la barra-->
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
		
		<div class="container-fluid">

			<img src="./img/favicon.png">
            <div class="collapse navbar-collapse row justify-content-end"> 	
				<div class="col-auto">
					<div class="col-auto text-white px-3 py-2">Logueado como: <?php echo $_SESSION['username']?></div>
				</div>
				<div class="col-auto">
					<a type="button" href="./procesoLogout.php" class="g-3 btn btn-danger">Cerrar sesión</a>
				</div>
            </div>

		</div>

</nav>
<!-- fin de la barra 




-->