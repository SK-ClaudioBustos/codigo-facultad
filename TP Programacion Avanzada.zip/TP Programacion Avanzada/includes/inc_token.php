<!-- Generación de token -->
<?php
	session_start();
	$token = rand(5, 1500);
	$token_captcha = rand(100000,999999);
	$_SESSION ['token'] = $token;
	$_SESSION ['token_captcha'] = $token_captcha;
?>
<!-- Fin de generacion token -->