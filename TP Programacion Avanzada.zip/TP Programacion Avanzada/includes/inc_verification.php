<?php
	session_start();
	if (isset($_SESSION['username'])){
        $usuario = $_SESSION['username'];
    }else{
        header('Location: index.php');
        die();
    }
?>