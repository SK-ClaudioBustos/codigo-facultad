<?php
	require_once("./includes/inc_token.php");
?>

<!DOCTYPE html>
<html>

<head>
	<title>Iniciar sesión</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="./css/index.css" rel="stylesheet">
</head>

<body class="bg-black">
	<!-- Comienzo de la barra -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
		<div class="container-fluid justify-content-start d-flex align-items-center bg-dark col-4">
			<a class="navbar-brand" href="#"><img src="./img/favicon.png"></a>
			<a class="navbar-brand" href="#"><img src="./img/logoLetrasTrans.png" height="24"></a>
		</div>
		<div class="container-fluid d-flex justify-content-end align-items-center bg-dark col-8">

			
			<?php
			//<!-- Cartel de ingreso de datos incorrectos -->
			if (isset($_GET['logfail']) && $_GET['logfail'] == true) {
			?>
				<div id="cartelito" class="col-auto text-danger px-3 py-2">Nombre de usuario o contraseña incorrectos</div>
			<?php
			}
			?>

			<?php
			//<!-- Cartel de conexion fallida con la base de datos -->
			if (isset($_GET['bsfail']) && $_GET['bsfail'] == true) {
			?>
				<div class="col-auto text-danger px-3 py-2">Conexión a la base de datos fallida</div>
				<script>
					console.log(<?= $_GET['msg_error']?>);
					console.log(<?= $_GET['msg_error_code']?>);
				</script>
			<?php
			}
			?>
			
			<?php
			//<!-- Cartel de inicio de sesion fallida por diferencia de token -->
			if (isset($_GET['tokenfail']) && ($_GET['tokenfail'] == true)) {
			?>
				<div class="col-auto text-danger px-3 py-2">No se ha podido iniciar sesión</div>
			<?php
			}
			?>

			<?php
			//<!-- Cartel de mail repetido -->
			if (isset($_GET['emailfail']) && ($_GET['emailfail'] == true)) {
			?>
				<div class="col-auto text-danger px-3 py-2">Ya existe una cuenta asociada al email ingresado</div>
			<?php
			}
			?>

			<?php
			//<!-- Cartel de usuario registrado -->
			if (isset($_GET['newuser']) && ($_GET['newuser'] == true)) {
			?>
				<div class="col-auto text-success px-3 py-2">Usted se ha registrado correctamente</div>
			<?php
			}
			?>

			<!-- Botones de la barra -->
			<div class="row g-3">
				<div class="col-auto">
					<button type="button" class="btn btn-success" data-bs-target="#modal-inicio" data-bs-toggle="modal">Iniciar sesión</button>
				</div>
				<div class="col-auto">
					<button type="button" class="btn btn-secondary" data-bs-target="#modal-registro" data-bs-toggle="modal">Registrarse</button>
				</div>
			</div>
		</div>
	</nav>

	<!-- Comienzo pop up inicio sesion -->
	<div id="modal-inicio" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content bg-dark text-white">
				<div class="modal-header">
					<h5 class="modal-title">Iniciar Sesión</h5>
				</div>

				<div class="modal-body">
					<!-- Comienzo del formulario -->
					<form action="procesoLogin.php" method="post" onsubmit="verificarDatosIS()" class="row g-3">
						<div class="row-auto">
							<input pattern="[a-zA-Z][a-zA-Z0-9_]+" minlength="3" maxlength="40" title="Debe comenzar con una letra y puede contener letras, dígitos o guiones" type="text" class="form-control" id="username" name="username" placeholder="Usuario" required></br>
							<input pattern="[a-zA-Z0-9&_\-\.\*\s]+" minlength="8" maxlength="40" title="Puede contener letras, dígitos y simbolos" type="password" class="form-control" id="password" name="password" placeholder="Contraseña" required>
							<p class="form-control text-danger bg-dark text-center border-danger rounded mt-4" id="captcha"><?php echo $token_captcha ?></p>
							<input pattern="[0-9]+" minlength="6" maxlength="6" title="Ingrese el captcha" type="text" class="form-control mt-4" id="token_captcha" name="token_captcha" placeholder="Escribe el captcha" value="" required>
						</div>
						<div class="modal-footer">
							<input type="hidden" name="token" value="<?php echo $token ?>">
							<button type="submit" class="btn btn-success">Ingresar</button>
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
						</div>
					</form>
					<!-- Fin del formulario-->
				</div>
			</div>
		</div>
	</div>
	<!-- Fin pop up inicio sesion -->
	
	<!-- Comienzo pop up registro -->
	<div id="modal-registro" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content bg-dark text-white">
				<div class="modal-header">
					<h5 class="modal-title">Registrarse</h5>
				</div>

				<div class="modal-body">
					<!-- Comienzo del formulario -->
					<form action="nuevoUsuario.php" method="post" onsubmit="verificarDatosR()" class="row g-3">
						<div class="row-auto">
							<input pattern="[a-zA-Z][a-zA-Z0-9_]+" minlength="3" maxlength="40" title="Debe comenzar con una letra y puede contener letras, dígitos o guiones" type="text" class="form-control" id="reg_username" name="reg_username" placeholder="Usuario" required></br>
							<input pattern="[a-zA-Z0-9&_\-\.\*\s]+" title="Puede contener letras, dígitos y simbolos" type="password" class="form-control" id="reg_password" name="reg_password" placeholder="Contraseña" required>
							<input pattern="[a-zA-Z]+" title="Ingrese su nombre" type="text" class="form-control mt-4" id="reg_nombre" name="reg_nombre" placeholder="Nombre" required>
							<input pattern="[a-zA-Z]+" title="Ingrese su apellido"type="text" class="form-control mt-4" id="reg_apellido" name="reg_apellido" placeholder="Apellido" required>
							<input type="email" class="form-control mt-4" id="reg_email" name="reg_email" placeholder="Correo electrónico" required>
							<p class="form-control text-danger bg-dark text-center border-danger rounded mt-4" id="captcha"><?php echo $token_captcha ?></p>
							<input pattern="[0-9]+" title="Ingrese el captcha" type="text" class="form-control mt-4" id="token_captcha" name="token_captcha" placeholder="Escribe el captcha" value="" required>
						</div>
						<div class="modal-footer">
							<input type="hidden" name="token" value="<?php echo $token ?>">
							<button type="submit" class="btn btn-success">Registrar</button>
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
						</div>
					</form>
					<!-- Fin del formulario-->
				</div>
			</div>
		</div>
	</div>
	<!-- Fin pop up registro -->		
			
	<div class="fondo">
		<br><br>
		<!-- Comienzo del carrusel-->
		<div id="carouselExampleIndicators" class="carousel slide container w-75" data-bs-ride="true">
			<div class="carousel-indicators">
				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
			</div>
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img src="./img/bannerCopaNediel.png" class="d-block w-100" alt="Copa Nediel">
				</div>
				<div class="carousel-item">
					<img src="./img/bannerHattrick.png" class="d-block w-100" alt="Hattrick">
				</div>
				<div class="carousel-item">
					<img src="./img/bannerTwitch.png" class="d-block w-100" alt="Canal de Twitch">
				</div>
			</div>
			<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Anterior</span>
			</button>
			<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Siguiente</span>
			</button>
		</div>
		<!-- Fin del carrusel-->
	</div>
	<script type="text/javascript" src="./js/validarInicioSesion.js"></script>
	<script type="text/javascript" src="./js/validarRegistro.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
<?php
	require_once("./includes/inc_footer.php");
?>
</html>