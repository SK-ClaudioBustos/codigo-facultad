<?php
    try{
        $email = $_POST['reg_email'];
        $mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
        $sql = "select usu_email from usuario
                    where usu_email = '".$email."'";
        $result = $mysqli->query($sql);
        if(!sizeOf($result->fetch_array())){
            $user = $_POST['reg_username'];
            $pass = password_hash($_POST['reg_password'],PASSWORD_DEFAULT);
            $nom = $_POST['reg_nombre'];
            $ape = $_POST['reg_apellido'];
            $sql = "INSERT INTO usuario(usu_nombre_usuario,usu_pass,usu_nombre,usu_apellido,usu_email) 
                    VALUES('".$user."','".$pass."','".$nom."','".$ape."','".$email."')";
			$mysqli->query($sql);
            $mysqli->close();
            header("location:index.php?newuser=true");    
        }
        else{
            $mysqli->close();
            header("location:index.php?emailfail=true");   
        }
    }
    catch(Exception $error){
        $msg_error = mysqli_connect_error();
        $msg_error_code = mysqli_errno($mysqli);
        $mysqli->close();
        header("location:index.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code"); 
    }   
?>