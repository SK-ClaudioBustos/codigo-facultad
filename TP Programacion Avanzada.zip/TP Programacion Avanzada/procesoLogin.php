<?php
	session_start();
	if ($_POST['token'] == $_SESSION['token'] && $_POST['token_captcha'] == $_SESSION['token_captcha'] ){	
    	try{
    		$mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
			$sql ="select usu_nombre_usuario,usu_pass from usuario
            	  where usu_nombre_usuario = '".$_POST['username']."'
           		  and usu_pass='".password_hash($_POST['password'],PASSWORD_DEFAULT)."'";
			$result = $mysqli->query($sql);
			if(!sizeOf($result->fetch_array())){
				$_SESSION['username']=$_POST['username'];
				header("location:inicio.php");
			}else{
				header("location:index.php?logfail=true");
			}
			$mysqli->close();
		}
    	catch(Exception $errorConecction){
    		$msg_error = mysqli_connect_error();
	        $msg_error_code = mysqli_errno($mysqli);
	        $mysqli->close();
	        header("location:index.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code");
    	}
	}
	else{
		header("location:index.php?tokenfail=1");
	}
?>