function verificarDatosIS(){
    console.log("Verificando datos introducidos en el inicio de sesion...");
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    if(user.search("'") != -1 || pass.search("'") != -1 || user.search("<") != -1 || pass.search("<") != -1 || user.search(">") != -1 || pass.search(">") != -1 || user.search("<>") != -1 || pass.search("<>") != -1){
        console.log("Se a intentado realizar una inyeccion SQL");
        let mensaje = document.getElementById("cartelito");
        mensaje.textContent = "No esta permitido hacer un inyeccion SQL";
    }
    else{
        console.log("Los datos ingresados son seguros");
    }
}



