function verificarDatosR(){
    console.log("Verificando datos introducidos en el registro...");
    const user = document.getElementById("reg_username").value;
    const pass = document.getElementById("reg_password").value;
    const nom = document.getElementById("reg_nombre").value;
    const ape = document.getElementById("reg_apellido").value;
    const email = document.getElementById("reg_email").value;
    if(user.search("'") != -1 || pass.search("'") != -1 || nom.search("'") != -1 || ape.search("'") != -1 || email.search("'") != -1
    || user.search("<") != -1 || pass.search("<") != -1 || nom.search("<") != -1 || ape.search("<") != -1 || email.search("<") != -1
    || user.search(">") != -1 || pass.search(">") != -1 || nom.search(">") != -1 || ape.search(">") != -1 || email.search(">") != -1
    || user.search("<>") != -1 || pass.search("<>") != -1 || nom.search("<>") != -1 || ape.search("<>") != -1 || email.search("<>") != -1){
        console.log("Se a intentado realizar una inyeccion SQL");
        let mensaje = document.getElementById("cartelito");
        mensaje.textContent = "No esta permitido hacer un inyeccion SQL";
    }
    else{
        console.log("Los datos ingresados son seguros");
    }
}