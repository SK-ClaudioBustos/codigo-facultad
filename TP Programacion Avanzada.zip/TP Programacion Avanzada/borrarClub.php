<?php
	try{
		$mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
		$sql = "delete from club where clu_id = '".$_GET['selection']."'";
		$mysqli->query($sql);
		$mysqli->close();
		header("location:inicio.php");
	}
	catch(Exception $error){
		$msg_error = mysqli_connect_error();
        $msg_error_code = mysqli_errno($mysqli);
        $mysqli->close();
        header("location:index.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code");
	}
?>