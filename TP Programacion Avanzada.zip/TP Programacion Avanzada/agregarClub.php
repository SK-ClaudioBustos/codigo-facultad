<?php 
    try{
		$mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
		$partes = explode('-', $_POST['fundacion']); 
    	$fecha = $partes[2]."-".$partes[1]."-".$partes[0];
    	$nom1 = $_POST['nombre_largo'];
    	$nom2 = $_POST['nombre_medio'];
    	$nom3 = $_POST['nombre_corto'];
    	$ciu = $_POST['ciudad'];
    	$pai = $_POST['pais'];
		$sql = "INSERT INTO club(clu_nombre_largo,clu_nombre_medio,clu_nombre_corto,clu_fundacion,clu_ciudad,clu_pais) 
				VALUES('".$nom1."','".$nom2."','".$nom3."','".$fecha."','".$ciu."','".$pai."')";			
		$mysqli->query($sql);
		$mysqli->close();
		header("location:inicio.php");
	}
	catch(Exception $error){
        $msg_error = mysqli_connect_error();
        $msg_error_code = mysqli_errno($mysqli);
        $mysqli->close();
        header("location:inicio.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code"); 
    }  
?>