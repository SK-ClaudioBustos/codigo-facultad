<?php
	try{
		$mysqli = new mysqli('localhost', '2022_grupo1','Grupo1_2090', '2022_grupo1');
		$sql = "select clu_id,clu_nombre_largo,clu_nombre_medio,clu_nombre_corto,clu_fundacion,clu_ciudad,clu_pais from club where clu_id = '".$_GET['selection']."'";
		$resultado=$mysqli->query($sql);
		$mysqli->close();
		while ( $club = $resultado->fetch_assoc()){;
            $e_id=$club["clu_id"];
            $e_nl=$club["clu_nombre_largo"];
            $e_nm=$club["clu_nombre_medio"];
            $e_nc=$club["clu_nombre_corto"];
            $e_fund=$club["clu_fundacion"];
            $e_ciu=$club["clu_ciudad"];
			$e_pais=$club["clu_pais"];
		}
	}
	catch(Exception $error){
		$msg_error = mysqli_connect_error();
        $msg_error_code = mysqli_errno($mysqli);
        $mysqli->close();
        header("location:index.php?bsfail=true&msg_error=$msg_error&msg_error_code=$msg_error_code");
	}
?>


<!DOCTYPE html>
<html>

	<head>
		<title>Edición</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
		<link rel="stylesheet" type="text/css" href="./css/tabla.css">
	</head>
	
	<body class="h-100 bg-black text-white text-center">
		<?php
			session_start();
			require_once("./includes/inc_header.php");
		?>	


		<form action="editarClub.php?selection=<?php echo $e_id; ?>" method="post" class="row g-3">
			<div class="row-auto">
				<input pattern="[a-zA-Z\s]+" value="<?php echo $e_nl; ?>" title="Nombre largo del club" type="text" class="form-control text-black" name="nombre_largo" placeholder="Nombre Largo" required></br>
				<input pattern="[a-zA-Z\s]+" value="<?php echo $e_nm; ?>"title="Nombre corto" type="text" class="form-control text-black" name="nombre_medio" placeholder="Nombre Corto" required>
				<input pattern="[a-zA-Z]+" value="<?php echo $e_nc; ?>" minlenght="3" maxlength="3" title="Abreviación(solo 3 caracteres)" type="text" class="form-control mt-4 text-black" name="nombre_corto" placeholder="Abreviación" required>
				<input pattern="([0-9]{2}-[0-9]{2}-[0-9]{4})+" title="Fecha de fundación(dd-mm-aaaa)" type="text" class="form-control mt-4 text-black" name="fundacion" placeholder="Fecha de Fundación" required>
				<input pattern="[a-zA-Z\s]+" title="Ciudad" value="<?php echo $e_ciu; ?>" type="text" class="form-control mt-4 text-black" name="ciudad" placeholder="Ciudad" required>
				<input pattern="[a-zA-Z\s]+" title="País" value="<?php echo $e_pais; ?>" type="text" class="form-control mt-4 text-black" name="pais" placeholder="Pais" required>
			</div>
			<div class="buttons">
				<button type="submit" class="btn btn-success">Confirmar</button>
				<a type="button" href="./inicio.php" class="btn btn-secondary">Cancelar</a>
			</div>
		</form>

	</body>

	<div class="fixed-bottom">
		<?php 
			require_once("./includes/inc_footer.php");
		?>
	</div>
</html>	
